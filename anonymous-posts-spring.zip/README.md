# Anonymous Posts Spring Boot Project

Spring Boot application for anonymous posts and comments.

## Features

- PostgreSQL database.
- Flyway migration creates the `posts` and `comments` tables.
- DTO classes for post and comment requests/responses.
- REST controllers:
  - `PostController` on `/post`
  - `ComentController` on `/comment`
- Service, repository, and mapper layers.
- `.jpg` photo upload to the local `uploads` folder.
- `index.html` shows all posts and lets users create a new post.
- `post.html` shows one post, its comments, and a comment form.

## Requirements

- Java 17 or newer.
- Maven.
- PostgreSQL.

Check Java and Maven:

```bash
java -version
mvn -version
```

## PostgreSQL Setup

Install PostgreSQL. During installation, you can choose this password for the `postgres` user:

```text
postgres
```

Create the database:

```sql
CREATE DATABASE anonymous_posts;
```

You can run this in pgAdmin, or in SQL Shell / psql after connecting as the `postgres` user.

The project is configured with these default values:

```properties
spring.datasource.url=jdbc:postgresql://localhost:5432/anonymous_posts
spring.datasource.username=postgres
spring.datasource.password=postgres
```

If your PostgreSQL password is different, edit this file:

```text
src/main/resources/application.properties
```

Change:

```properties
spring.datasource.password=your_password_here
```

The project also supports environment variables:

```text
SPRING_DATASOURCE_URL
SPRING_DATASOURCE_USERNAME
SPRING_DATASOURCE_PASSWORD
```

## Run The Project

Open a terminal in the folder where `pom.xml` is located, then run:

```bash
mvn spring-boot:run
```

Open the site:

```text
http://localhost:8989
```

## Flyway

Flyway migration file:

```text
src/main/resources/db/migration/V1__create_posts_and_comments.sql
```

When the app starts for the first time, Flyway creates:

```text
posts
comments
flyway_schema_history
```

## Photo Uploads

- Only `.jpg` files are accepted.
- Uploaded photos are saved in the local `uploads` folder.
- Photos are served from:

```text
/uploads/{fileName}
```

## Build JAR

```bash
mvn clean package
java -jar target/anonymous-posts-0.0.1-SNAPSHOT.jar
```
