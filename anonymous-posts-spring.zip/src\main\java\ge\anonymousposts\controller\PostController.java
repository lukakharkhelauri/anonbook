package ge.anonymousposts.controller;

import ge.anonymousposts.dto.PostCreateDto;
import ge.anonymousposts.dto.PostDetailsDto;
import ge.anonymousposts.dto.PostResponseDto;
import ge.anonymousposts.service.PostService;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/post")
public class PostController {

    private final PostService postService;

    public PostController(PostService postService) {
        this.postService = postService;
    }

    @GetMapping
    public List<PostResponseDto> getAllPosts() {
        return postService.getAllPosts();
    }

    @GetMapping("/{id}")
    public PostDetailsDto getPost(@PathVariable Long id) {
        return postService.getPost(id);
    }

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<PostResponseDto> createPost(@Valid @ModelAttribute PostCreateDto dto) {
        PostResponseDto created = postService.createPost(dto);
        return ResponseEntity.created(URI.create("/post/" + created.getId())).body(created);
    }
}
