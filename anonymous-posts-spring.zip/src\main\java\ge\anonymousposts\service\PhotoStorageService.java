package ge.anonymousposts.service;

import org.springframework.web.multipart.MultipartFile;

public interface PhotoStorageService {

    String saveJpg(MultipartFile photo);

    String getPhotoUrl(String fileName);
}
