package ge.anonymousposts.service;

import ge.anonymousposts.dto.CommentCreateDto;
import ge.anonymousposts.dto.CommentResponseDto;
import java.util.List;

public interface CommentService {

    List<CommentResponseDto> getCommentsByPost(Long postId);

    CommentResponseDto createComment(CommentCreateDto dto);
}
