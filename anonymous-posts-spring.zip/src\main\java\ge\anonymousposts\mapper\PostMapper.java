package ge.anonymousposts.mapper;

import ge.anonymousposts.dto.PostCreateDto;
import ge.anonymousposts.dto.PostResponseDto;
import ge.anonymousposts.entity.Post;
import org.springframework.stereotype.Component;

@Component
public class PostMapper {

    public Post toEntity(PostCreateDto dto, String photoFileName) {
        Post post = new Post();
        post.setTitle(dto.getTitle().trim());
        post.setContent(dto.getContent().trim());
        post.setPhotoFileName(photoFileName);
        return post;
    }

    public PostResponseDto toResponse(Post post, String photoUrl, long commentCount) {
        return new PostResponseDto(
                post.getId(),
                post.getTitle(),
                post.getContent(),
                photoUrl,
                post.getCreatedAt(),
                commentCount
        );
    }
}
