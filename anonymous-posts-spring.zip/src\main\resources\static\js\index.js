const postsContainer = document.querySelector("#posts");
const postForm = document.querySelector("#postForm");
const formMessage = document.querySelector("#formMessage");
const refreshButton = document.querySelector("#refreshButton");

document.addEventListener("DOMContentLoaded", loadPosts);
refreshButton.addEventListener("click", loadPosts);

postForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    clearMessage(formMessage);

    const photo = postForm.photo.files[0];
    if (photo && !photo.name.toLowerCase().endsWith(".jpg")) {
        showMessage(formMessage, "ფოტო უნდა იყოს .jpg ფორმატში.", true);
        return;
    }

    const submitButton = postForm.querySelector("button[type='submit']");
    submitButton.disabled = true;

    try {
        const response = await fetch("/post", {
            method: "POST",
            body: new FormData(postForm)
        });

        if (!response.ok) {
            throw new Error(await readError(response));
        }

        postForm.reset();
        showMessage(formMessage, "პოსტი დამატებულია.");
        await loadPosts();
    } catch (error) {
        showMessage(formMessage, error.message, true);
    } finally {
        submitButton.disabled = false;
    }
});

async function loadPosts() {
    postsContainer.innerHTML = "<p class=\"empty-state\">იტვირთება...</p>";

    try {
        const response = await fetch("/post");
        if (!response.ok) {
            throw new Error(await readError(response));
        }

        const posts = await response.json();
        renderPosts(posts);
    } catch (error) {
        postsContainer.innerHTML = "";
        postsContainer.append(createEmptyState(error.message));
    }
}

function renderPosts(posts) {
    postsContainer.innerHTML = "";

    if (!posts.length) {
        postsContainer.append(createEmptyState("ჯერ არცერთი პოსტი არ არის დამატებული."));
        return;
    }

    posts.forEach((post) => {
        postsContainer.append(createPostCard(post, true));
    });
}

function createPostCard(post, includeLink) {
    const article = document.createElement("article");
    article.className = "post-card";

    if (post.photoUrl) {
        const image = document.createElement("img");
        image.className = "post-photo";
        image.src = post.photoUrl;
        image.alt = "პოსტის ფოტო";
        article.append(image);
    }

    const body = document.createElement("div");
    body.className = "post-body";

    const title = document.createElement("h3");
    title.className = "post-title";
    title.textContent = post.title;

    const meta = document.createElement("div");
    meta.className = "post-meta";
    meta.append(createSpan(formatDate(post.createdAt)));
    meta.append(createSpan(`${post.commentCount} კომენტარი`));

    const text = document.createElement("p");
    text.className = "post-text";
    text.textContent = post.content;

    body.append(title, meta, text);

    if (includeLink) {
        const link = document.createElement("a");
        link.className = "button-link";
        link.href = `/post.html?id=${post.id}`;
        link.textContent = "View Post";
        body.append(link);
    }

    article.append(body);
    return article;
}

function createSpan(text) {
    const span = document.createElement("span");
    span.textContent = text;
    return span;
}

function createEmptyState(text) {
    const empty = document.createElement("p");
    empty.className = "empty-state";
    empty.textContent = text;
    return empty;
}

function formatDate(value) {
    if (!value) {
        return "";
    }
    return new Intl.DateTimeFormat("ka-GE", {
        dateStyle: "medium",
        timeStyle: "short"
    }).format(new Date(value));
}

async function readError(response) {
    try {
        const data = await response.json();
        if (data.details && data.details.length) {
            return data.details.join(", ");
        }
        return data.message || "მოთხოვნა ვერ შესრულდა.";
    } catch {
        return "მოთხოვნა ვერ შესრულდა.";
    }
}

function showMessage(element, text, isError = false) {
    element.textContent = text;
    element.classList.toggle("error", isError);
}

function clearMessage(element) {
    showMessage(element, "", false);
}
