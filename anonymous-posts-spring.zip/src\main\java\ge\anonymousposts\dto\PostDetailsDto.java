package ge.anonymousposts.dto;

import java.util.List;

public class PostDetailsDto {

    private PostResponseDto post;
    private List<CommentResponseDto> comments;

    public PostDetailsDto() {
    }

    public PostDetailsDto(PostResponseDto post, List<CommentResponseDto> comments) {
        this.post = post;
        this.comments = comments;
    }

    public PostResponseDto getPost() {
        return post;
    }

    public void setPost(PostResponseDto post) {
        this.post = post;
    }

    public List<CommentResponseDto> getComments() {
        return comments;
    }

    public void setComments(List<CommentResponseDto> comments) {
        this.comments = comments;
    }
}
