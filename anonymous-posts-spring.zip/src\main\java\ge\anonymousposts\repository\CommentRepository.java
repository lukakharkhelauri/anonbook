package ge.anonymousposts.repository;

import ge.anonymousposts.entity.Comment;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommentRepository extends JpaRepository<Comment, Long> {

    List<Comment> findByPost_IdOrderByCreatedAtAscIdAsc(Long postId);

    long countByPost_Id(Long postId);
}
