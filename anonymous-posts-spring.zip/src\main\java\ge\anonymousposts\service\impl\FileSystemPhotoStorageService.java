package ge.anonymousposts.service.impl;

import ge.anonymousposts.config.FileStorageProperties;
import ge.anonymousposts.service.PhotoStorageService;
import jakarta.annotation.PostConstruct;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

@Service
public class FileSystemPhotoStorageService implements PhotoStorageService {

    private final Path uploadPath;

    public FileSystemPhotoStorageService(FileStorageProperties fileStorageProperties) {
        this.uploadPath = Paths.get(fileStorageProperties.getUploadDir()).toAbsolutePath().normalize();
    }

    @PostConstruct
    void init() {
        try {
            Files.createDirectories(uploadPath);
        } catch (IOException e) {
            throw new IllegalStateException("Could not create uploads directory", e);
        }
    }

    @Override
    public String saveJpg(MultipartFile photo) {
        if (photo == null || photo.isEmpty()) {
            return null;
        }

        validateJpg(photo);

        String fileName = UUID.randomUUID() + ".jpg";
        Path target = uploadPath.resolve(fileName).normalize();

        try (InputStream inputStream = photo.getInputStream()) {
            Files.copy(inputStream, target, StandardCopyOption.REPLACE_EXISTING);
            return fileName;
        } catch (IOException e) {
            throw new IllegalStateException("Could not save photo", e);
        }
    }

    @Override
    public String getPhotoUrl(String fileName) {
        if (fileName == null || fileName.isBlank()) {
            return null;
        }
        return "/uploads/" + fileName;
    }

    private void validateJpg(MultipartFile photo) {
        String originalFilename = photo.getOriginalFilename();
        String extension = originalFilename == null ? "" : StringUtils.getFilenameExtension(originalFilename);
        if (!"jpg".equalsIgnoreCase(extension)) {
            throw new IllegalArgumentException("Only .jpg photos are allowed");
        }

        String contentType = photo.getContentType();
        if (contentType != null && !MediaType.IMAGE_JPEG_VALUE.equalsIgnoreCase(contentType)) {
            throw new IllegalArgumentException("Only JPEG image content is allowed");
        }
    }
}
