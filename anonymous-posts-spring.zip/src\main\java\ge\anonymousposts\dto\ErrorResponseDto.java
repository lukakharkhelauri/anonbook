package ge.anonymousposts.dto;

import java.time.LocalDateTime;
import java.util.List;

public class ErrorResponseDto {

    private LocalDateTime timestamp;
    private String message;
    private List<String> details;

    public ErrorResponseDto() {
    }

    public ErrorResponseDto(String message, List<String> details) {
        this.timestamp = LocalDateTime.now();
        this.message = message;
        this.details = details;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<String> getDetails() {
        return details;
    }

    public void setDetails(List<String> details) {
        this.details = details;
    }
}
