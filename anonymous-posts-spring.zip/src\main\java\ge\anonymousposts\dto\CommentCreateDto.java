package ge.anonymousposts.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class CommentCreateDto {

    @NotNull(message = "Post id is required")
    private Long postId;

    @NotBlank(message = "Comment is required")
    @Size(max = 2000, message = "Comment must be 2000 characters or fewer")
    private String content;

    public Long getPostId() {
        return postId;
    }

    public void setPostId(Long postId) {
        this.postId = postId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
