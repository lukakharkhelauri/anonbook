package ge.anonymousposts.service.impl;

import ge.anonymousposts.dto.CommentResponseDto;
import ge.anonymousposts.dto.PostCreateDto;
import ge.anonymousposts.dto.PostDetailsDto;
import ge.anonymousposts.dto.PostResponseDto;
import ge.anonymousposts.entity.Post;
import ge.anonymousposts.exception.ResourceNotFoundException;
import ge.anonymousposts.mapper.CommentMapper;
import ge.anonymousposts.mapper.PostMapper;
import ge.anonymousposts.repository.CommentRepository;
import ge.anonymousposts.repository.PostRepository;
import ge.anonymousposts.service.PhotoStorageService;
import ge.anonymousposts.service.PostService;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PostServiceImpl implements PostService {

    private final PostRepository postRepository;
    private final CommentRepository commentRepository;
    private final PostMapper postMapper;
    private final CommentMapper commentMapper;
    private final PhotoStorageService photoStorageService;

    public PostServiceImpl(
            PostRepository postRepository,
            CommentRepository commentRepository,
            PostMapper postMapper,
            CommentMapper commentMapper,
            PhotoStorageService photoStorageService) {
        this.postRepository = postRepository;
        this.commentRepository = commentRepository;
        this.postMapper = postMapper;
        this.commentMapper = commentMapper;
        this.photoStorageService = photoStorageService;
    }

    @Override
    @Transactional(readOnly = true)
    public List<PostResponseDto> getAllPosts() {
        return postRepository.findAllByOrderByCreatedAtDesc()
                .stream()
                .map(post -> postMapper.toResponse(
                        post,
                        photoStorageService.getPhotoUrl(post.getPhotoFileName()),
                        commentRepository.countByPost_Id(post.getId())
                ))
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public PostDetailsDto getPost(Long id) {
        Post post = findPost(id);
        List<CommentResponseDto> comments = commentRepository.findByPost_IdOrderByCreatedAtAscIdAsc(id)
                .stream()
                .map(commentMapper::toResponse)
                .toList();

        PostResponseDto postDto = postMapper.toResponse(
                post,
                photoStorageService.getPhotoUrl(post.getPhotoFileName()),
                comments.size()
        );

        return new PostDetailsDto(postDto, comments);
    }

    @Override
    @Transactional
    public PostResponseDto createPost(PostCreateDto dto) {
        String photoFileName = photoStorageService.saveJpg(dto.getPhoto());
        Post post = postMapper.toEntity(dto, photoFileName);
        Post saved = postRepository.save(post);
        return postMapper.toResponse(
                saved,
                photoStorageService.getPhotoUrl(saved.getPhotoFileName()),
                0
        );
    }

    private Post findPost(Long id) {
        return postRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Post not found with id: " + id));
    }
}
