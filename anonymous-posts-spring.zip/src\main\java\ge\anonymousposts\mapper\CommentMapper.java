package ge.anonymousposts.mapper;

import ge.anonymousposts.dto.CommentCreateDto;
import ge.anonymousposts.dto.CommentResponseDto;
import ge.anonymousposts.entity.Comment;
import ge.anonymousposts.entity.Post;
import org.springframework.stereotype.Component;

@Component
public class CommentMapper {

    public Comment toEntity(CommentCreateDto dto, Post post) {
        Comment comment = new Comment();
        comment.setPost(post);
        comment.setContent(dto.getContent().trim());
        return comment;
    }

    public CommentResponseDto toResponse(Comment comment) {
        return new CommentResponseDto(
                comment.getId(),
                comment.getPost().getId(),
                comment.getContent(),
                comment.getCreatedAt()
        );
    }
}
