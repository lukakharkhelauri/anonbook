const postContainer = document.querySelector("#postContainer");
const commentsContainer = document.querySelector("#commentsContainer");
const commentForm = document.querySelector("#commentForm");
const commentMessage = document.querySelector("#commentMessage");
const postId = new URLSearchParams(window.location.search).get("id");

document.addEventListener("DOMContentLoaded", loadPostPage);

commentForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    clearMessage(commentMessage);

    const submitButton = commentForm.querySelector("button[type='submit']");
    submitButton.disabled = true;

    try {
        const response = await fetch("/comment", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                postId: Number(postId),
                content: commentForm.content.value
            })
        });

        if (!response.ok) {
            throw new Error(await readError(response));
        }

        window.location.reload();
    } catch (error) {
        showMessage(commentMessage, error.message, true);
        submitButton.disabled = false;
    }
});

async function loadPostPage() {
    if (!postId) {
        postContainer.append(createEmptyState("პოსტის id ვერ მოიძებნა."));
        commentForm.style.display = "none";
        return;
    }

    postContainer.innerHTML = "<p class=\"empty-state\">იტვირთება...</p>";

    try {
        const response = await fetch(`/post/${postId}`);
        if (!response.ok) {
            throw new Error(await readError(response));
        }

        const details = await response.json();
        renderPost(details.post);
        renderComments(details.comments);
    } catch (error) {
        postContainer.innerHTML = "";
        postContainer.append(createEmptyState(error.message));
        commentForm.style.display = "none";
    }
}

function renderPost(post) {
    postContainer.innerHTML = "";
    postContainer.append(createPostCard(post));
}

function renderComments(comments) {
    commentsContainer.innerHTML = "";

    if (!comments.length) {
        commentsContainer.append(createEmptyState("კომენტარები ჯერ არ არის."));
        return;
    }

    comments.forEach((comment) => {
        const item = document.createElement("article");
        item.className = "comment";

        const text = document.createElement("p");
        text.textContent = comment.content;

        const time = document.createElement("time");
        time.dateTime = comment.createdAt;
        time.textContent = formatDate(comment.createdAt);

        item.append(text, time);
        commentsContainer.append(item);
    });
}

function createPostCard(post) {
    const article = document.createElement("article");
    article.className = "post-card";

    if (post.photoUrl) {
        const image = document.createElement("img");
        image.className = "post-photo";
        image.src = post.photoUrl;
        image.alt = "პოსტის ფოტო";
        article.append(image);
    }

    const body = document.createElement("div");
    body.className = "post-body";

    const title = document.createElement("h3");
    title.className = "post-title";
    title.textContent = post.title;

    const meta = document.createElement("div");
    meta.className = "post-meta";
    meta.append(createSpan(formatDate(post.createdAt)));
    meta.append(createSpan(`${post.commentCount} კომენტარი`));

    const text = document.createElement("p");
    text.className = "post-text";
    text.textContent = post.content;

    body.append(title, meta, text);
    article.append(body);
    return article;
}

function createSpan(text) {
    const span = document.createElement("span");
    span.textContent = text;
    return span;
}

function createEmptyState(text) {
    const empty = document.createElement("p");
    empty.className = "empty-state";
    empty.textContent = text;
    return empty;
}

function formatDate(value) {
    if (!value) {
        return "";
    }
    return new Intl.DateTimeFormat("ka-GE", {
        dateStyle: "medium",
        timeStyle: "short"
    }).format(new Date(value));
}

async function readError(response) {
    try {
        const data = await response.json();
        if (data.details && data.details.length) {
            return data.details.join(", ");
        }
        return data.message || "მოთხოვნა ვერ შესრულდა.";
    } catch {
        return "მოთხოვნა ვერ შესრულდა.";
    }
}

function showMessage(element, text, isError = false) {
    element.textContent = text;
    element.classList.toggle("error", isError);
}

function clearMessage(element) {
    showMessage(element, "", false);
}
