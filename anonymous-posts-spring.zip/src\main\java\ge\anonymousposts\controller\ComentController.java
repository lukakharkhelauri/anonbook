package ge.anonymousposts.controller;

import ge.anonymousposts.dto.CommentCreateDto;
import ge.anonymousposts.dto.CommentResponseDto;
import ge.anonymousposts.service.CommentService;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/comment")
public class ComentController {

    private final CommentService commentService;

    public ComentController(CommentService commentService) {
        this.commentService = commentService;
    }

    @GetMapping("/post/{postId}")
    public List<CommentResponseDto> getCommentsByPost(@PathVariable Long postId) {
        return commentService.getCommentsByPost(postId);
    }

    @PostMapping
    public ResponseEntity<CommentResponseDto> createComment(@Valid @RequestBody CommentCreateDto dto) {
        CommentResponseDto created = commentService.createComment(dto);
        return ResponseEntity.created(URI.create("/comment/" + created.getId())).body(created);
    }
}
