CREATE DATABASE anonymous_posts;
