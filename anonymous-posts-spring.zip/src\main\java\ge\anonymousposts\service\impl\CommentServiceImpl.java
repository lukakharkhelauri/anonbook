package ge.anonymousposts.service.impl;

import ge.anonymousposts.dto.CommentCreateDto;
import ge.anonymousposts.dto.CommentResponseDto;
import ge.anonymousposts.entity.Comment;
import ge.anonymousposts.entity.Post;
import ge.anonymousposts.exception.ResourceNotFoundException;
import ge.anonymousposts.mapper.CommentMapper;
import ge.anonymousposts.repository.CommentRepository;
import ge.anonymousposts.repository.PostRepository;
import ge.anonymousposts.service.CommentService;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CommentServiceImpl implements CommentService {

    private final CommentRepository commentRepository;
    private final PostRepository postRepository;
    private final CommentMapper commentMapper;

    public CommentServiceImpl(CommentRepository commentRepository, PostRepository postRepository, CommentMapper commentMapper) {
        this.commentRepository = commentRepository;
        this.postRepository = postRepository;
        this.commentMapper = commentMapper;
    }

    @Override
    @Transactional(readOnly = true)
    public List<CommentResponseDto> getCommentsByPost(Long postId) {
        if (!postRepository.existsById(postId)) {
            throw new ResourceNotFoundException("Post not found with id: " + postId);
        }

        return commentRepository.findByPost_IdOrderByCreatedAtAscIdAsc(postId)
                .stream()
                .map(commentMapper::toResponse)
                .toList();
    }

    @Override
    @Transactional
    public CommentResponseDto createComment(CommentCreateDto dto) {
        Post post = postRepository.findById(dto.getPostId())
                .orElseThrow(() -> new ResourceNotFoundException("Post not found with id: " + dto.getPostId()));

        Comment comment = commentMapper.toEntity(dto, post);
        Comment saved = commentRepository.save(comment);
        return commentMapper.toResponse(saved);
    }
}
