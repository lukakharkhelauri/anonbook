package ge.anonymousposts.service;

import ge.anonymousposts.dto.PostCreateDto;
import ge.anonymousposts.dto.PostDetailsDto;
import ge.anonymousposts.dto.PostResponseDto;
import java.util.List;

public interface PostService {

    List<PostResponseDto> getAllPosts();

    PostDetailsDto getPost(Long id);

    PostResponseDto createPost(PostCreateDto dto);
}
